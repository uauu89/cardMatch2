/*

1. 두 번째 선택인 경우
    1-1. 첫번째 카드의 페어의 위치를 아는 경우
        1-1-1. 실수 없이 선택
        1-1-2. 실수 발생
    1-2. 첫번째 카드의 페어의 위치를 모르는 경우
        1-2-1. 공개되지 않은 카드에서만 선택
            1-2-1-1. 실수 없이 선택
            1-2-1-2. 실수 발생
        
2. 첫 번째 선택인 경우
    2-1. 짝이 맞는 카드의 위치를 아는 경우
        2-1-1. 실수 없이 선택
        2-1-2. 실수 발생

    2-2. 짝이 맞는 카드의 위치를 모르는 경우
        2-2-1. 이미 선택했던 카드 배열에서 선택
            2-2-1-1. 실수 없이 선택
            2-2-1-2. 실수 발생

        2-2-2. 공개되지 않은 카드에서 선택
            2-2-2-1. 실수 없이 선택
            2-2-2-2. 실수 발생



        

-- 옵션 종류

1-1. 첫번째 카드의 짝 선택확률
2-1. 짝이 공개된 카드를 선택할 확률
2-2-1. 이미 선택했던 카드 배열에서만 선택할 확률
2-2-1. 2) 

*/

import type { Type_currentPlayer } from "../types/game";


// 미사용
/*
const aiCase_pick_matchingSecondCard = (
    cards_selected: number[],
    cards_memory : (number | null)[],
) => {

    const selectedCardNumber = cards_memory[cards_selected[0]];
    const pairIndex = cards_memory.findIndex((value, index) => {
        value === selectedCardNumber && index !== cards_selected[0];
    })
    return pairIndex;
}
const aiCase_pick_knownPair = (
    cards_memory : (number | null)[],
    cards_owner: (Type_currentPlayer | null)[]
) => {
    const memoryMap: number[][] = Array.from({length: cards_memory.length / 2 + 1}, () => []);

    cards_memory.forEach((value, index) => {
        if(value !== null && cards_owner[index] === null){
            memoryMap[value].push(index);
            if(memoryMap[value].length === 2){
                return memoryMap[value][0];
            }
        }
    })

    return null;
}
const aiCase_random_fromUnknownArray = (
    cards_memory : (number | null)[],
) => {
    const filteredArray = cards_memory.reduce<number[]>((acc, current, index) => {
        if (current === null) {
            acc.push(index);
        }
        return acc;
    }, []);

    const com_index = Math.floor(Math.random() * filteredArray.length) ;
    return filteredArray[com_index];
}
const aiCase_random_fromKnownArray = (
    cards_opend: boolean[],
    cards_memory : (number | null)[],
    cards_owner: (Type_currentPlayer | null)[]
) => {
    const filteredArray = cards_memory.reduce<number[]>((acc, current, index) => {
        if (current !== null && cards_opend[index] === false, cards_owner[index] === null) {
            acc.push(index);
        }
        return acc;
    }, []);

    const com_index = Math.floor(Math.random() * filteredArray.length) ;
    return filteredArray[com_index];
}
*/
// 미사용




/*

com_idx 값을 배열로 전달,
정답을 아는 카드일 경우 두 개의 idx를 리턴

cardClick을 반복문으로 실행,

com_idx의 개수가 한개일 경우 comAlgorithm을 한번 더 실행

return값으로 알고리즘의 케이스도 같이 전달(실수여부는 제외)한 후 
checkMatch에서 알고리즘 케이스에 따라 정답 반응 다르게

예) 카드의 정답을 전부 아는 경우 "확신" 상태를 전달 / 실수 발생해서 잘못된 idx 값 전달
    - 확신 상태에서 정답 > 당연/당당 등의 이모지 출력
    - 확신 상태에서 오답 > 놀람(부정 의미)/당황등의 이모지 출력

    카드의 정답을 모르는 경우 "고민" 상태를 전달
    - 고민 상태에서 정답 > 놀람(긍정 의미)/신남 등의 이모지 출력
    - 고민 상태에서 오답 > 아쉬움(감정표현이 크지 않은) 등의 이모지 출력
*/

const behaviorChance = 100;
const mistakeChance = 10;

const dice = () => {
    return Math.floor(Math.random() * 100);
}

const classifyAvailableCards = (
    cards_memory : (number | null)[],
    cards_opend: boolean[],
    cards_owner: (Type_currentPlayer | null)[]
) => {
    const knownIndices: number[] = [];
    const unknownIndices: number[] = [];
    
    cards_memory.forEach((value, index) => {
        if(!cards_opend[index] && cards_owner[index] === null){
            if(value !== null){
                knownIndices.push(index);
            }else{
                unknownIndices.push(index)
            }
        }
    });
    return [knownIndices, unknownIndices];
}

const findMatchingCardIndex = (
    firstCardIndex: number | null,
    firstCardNumber:number | null,
    cards_memory: (number | null)[]
) => {
    if(firstCardIndex === null || firstCardNumber === null) return null;

    const firstIndex = cards_memory.indexOf(firstCardNumber);
    const lastIndex = cards_memory.lastIndexOf(firstCardNumber);
    if(firstIndex === lastIndex) return null;

    return [firstIndex === firstCardIndex? lastIndex : firstIndex];
}
const getPairIndices = (
    cards_memory : (number | null)[],
    cards_owner: (Type_currentPlayer | null)[]
) => {
    // 최초 filter = [(1번카드)[카드인덱스, 카드인덱스], (2번카드)[인덱스, 인덱스]...]
    const result: number[][] = Array.from({length: cards_memory.length / 2 + 1}, () => []);

    for(let i = 0; i < cards_memory.length; i++){
        const value = cards_memory[i];
        if(value !== null && cards_owner[i] === null){
            result[value].push(i);
            if(result[value].length === 2) return result[value]
        }
    }

    return null;
}
const insertWrongIndex = (
    targetIndices: number[],
    cards_owner: (Type_currentPlayer | null)[]
) => {
    const copyIndices = [...targetIndices];
    const filteredArray = cards_owner.reduce<number[]>((acc, current, index) => {
        if(current === null && !targetIndices.includes(index)){
            acc.push(index);
        }
        return acc;
    }, [])
    
    const randomRange = Math.floor(Math.random() * targetIndices.length) + 1;

    for(let i = 0; i < randomRange; i++){
        const randomOrder = Math.floor(Math.random() * filteredArray.length);
        copyIndices[i] = filteredArray.splice(randomOrder, 1)[0];
    }
    return copyIndices;
}

const pickRandomIndexFromArray = (targetArray : number[], count: 1 | 2) => {
    const copyTargetArray = [...targetArray]
    const returnArray = [];
    for(let i = 0; i < count; i++){
        const randomIndex = Math.floor(Math.random() * copyTargetArray.length);
        returnArray.push(...copyTargetArray.splice(randomIndex, 1));
    }
    return returnArray;
}
const pickRandomAll = (
    cards_opend: boolean[],
    cards_owner: (Type_currentPlayer | null)[]
) => {
    const filteredArray = cards_opend.reduce<number[]>((acc, isOpen, index) => {
        if (!isOpen && cards_owner[index] === null) {
            acc.push(index);
        }
        return acc;
    }, []);

    const com_index = Math.floor(Math.random() * filteredArray.length) ;
    return [filteredArray[com_index]];
}

export const comAlgorithm = (
    cards_selected: number[],
    cards_opend: boolean[],
    cards_memory : (number | null)[],
    cards_owner: (Type_currentPlayer | null)[]
) => {
    const firstCardIndex = cards_selected[0] ?? null;
    const firstCardNumber = firstCardIndex !== null ? cards_memory[firstCardIndex] : null;

    const pairSecondIndex = findMatchingCardIndex(firstCardIndex, firstCardNumber, cards_memory);
    const pairIndices = getPairIndices(cards_memory, cards_owner);
    
    const [knownIndices, unknownIndices] = classifyAvailableCards(cards_memory, cards_opend, cards_owner)

    const count_denominator = cards_owner.filter(owner => owner === null).length;
    const ratio_knownIndices = (knownIndices.length / count_denominator) * 100;
    

    // < dice() : 실수 X

    if(cards_selected.length === 1){    // 먼저 선택한 카드가 있는 경우
        if(pairSecondIndex !== null && behaviorChance > dice()){    // 짝 카드의 위치를 알 때 behavior = pairIndex
            return {
                comState : "lucky", 
                comIdx : mistakeChance < dice() 
                    ? pairSecondIndex
                    : pickRandomAll(cards_opend, cards_owner)
            } as const;
        }else{  //짝 카드의 위치를 모를 때
            if(knownIndices.length > 1 && ratio_knownIndices < 30 && count_denominator > 6 && behaviorChance > dice()){ // 열어본 카드가 몇장 없을 때 behavior = known
                const returnIndices = pickRandomIndexFromArray(knownIndices, 1);
                return {
                    comState : "tricky",
                    comIdx : mistakeChance < dice()
                        ? returnIndices
                        : insertWrongIndex(knownIndices, cards_owner)
                } as const;
                
            }
            if(behaviorChance > dice()){    //behavior = unknown
                const returnIndices = pickRandomIndexFromArray(unknownIndices, 1);
                return {
                    comState : "thinking",
                    comIdx : mistakeChance < dice()
                        ? returnIndices
                        : insertWrongIndex(unknownIndices, cards_owner)
                } as const;
            }
        }
    }
    
    if(pairIndices !== null && behaviorChance > dice()){ // 짝이 맞는 카드의 위치를 둘 다 아는 경우
        return {
            comState : "knowCorrect",
            comIdx : mistakeChance < dice() 
            ? pairIndices
            : insertWrongIndex(pairIndices, cards_owner)
        } as const;
    }

    if(knownIndices.length > 1 && ratio_knownIndices < 30 && count_denominator > 6 && behaviorChance > dice()){  // 남은 카드 비율이 조건을 충족하는 경우
        const returnIndices = pickRandomIndexFromArray(knownIndices, 2);
        return {
            comState : "tricky",
            comIdx : mistakeChance < dice()
                ? returnIndices
                : insertWrongIndex(knownIndices, cards_owner)
        } as const;
    }

    if(behaviorChance > dice()){
        const returnIndices = pickRandomIndexFromArray(unknownIndices, 2);

        return {
            comState : "thinking",
            comIdx : mistakeChance < dice()
                ? returnIndices
                : insertWrongIndex(unknownIndices, cards_owner)
        } as const;
    }

    return {
        comState : "thinking",
        comIdx : pickRandomAll(cards_opend, cards_owner)
    } as const;
}

