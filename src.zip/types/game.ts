export type Type_GamePhase = 
    "welcome"
    | "gameOver"
    | "gameStart"
    | "dealing"
    | "playing";

export type Type_ComState = 
    "default" 
    | "noEmotion" 
    | "knowCorrect" 
    | "tricky" 
    | "thinking" 
    | "correct" 
    | "wrong" 
    | "mistake" 
    | "lucky";


