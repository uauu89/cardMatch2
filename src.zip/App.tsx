import GameHUD from './component/GameHUD/GameHUD';
import GameBoard from './component/GameBoard/GameBoard';
import Settings from './component/Settings/Settings';
import GameOver from './component/GameOver/GameOver';

import "./CSS/fonts.css";
import "./CSS/variant.css";
import "./CSS/common.css";
import "./CSS/utility.css";
import { useEffect, useState } from 'react';
import { useGameStore } from './stores/useGameStore';
import { useShallow } from 'zustand/shallow';

function App() {
    const [gameStart, setGameStart] = useState<boolean>(false);

    const [opt_previewAnimation, setOpt_previewAnimation] = useState<boolean>(true);
    const [opt_timer, setOpt_timer] = useState<number>(5);

    const {gamePhase} = useGameStore(useShallow(state=>({
        gamePhase: state.gamePhase,
    })))

    const gameOver = ["ready", "gameOver"].includes(gamePhase);

    return (
        <>
            <GameHUD />
            <GameBoard 
                gameStart={gameStart}
                opt_previewAnimation = {opt_previewAnimation}
            />
            <Settings 
                opt_previewAnimation={opt_previewAnimation}
                setOpt_previewAnimation={setOpt_previewAnimation}
                opt_timer={opt_timer}
                setOpt_timer={setOpt_timer}
            />
            {gameOver && <GameOver />}
        </>
    )
}

export default App
